/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package priexamenpractico.proyectofinal;

import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class clsMenu {
    
    public void menuPrincipal(){
        char opcion = ' ';
        
        do {
            opcion = JOptionPane.showInputDialog("Seleccione una opcion: "
                    + "\nA.Equipos."
                    + "\nB.Presupuestos."
                    + "\nC.Calendario de jornadas."
                    + "\nD.Tabla de posiciones"
                    + "\nE.Mercado de jugadores."
                    + "\nF.Generador de mensajes."
                    + "\nG.Generador de convocatorias."
                    + "\nS.Salir").toUpperCase().charAt(0);
            
        } while (opcion != 'S');
        
    }
    
}
