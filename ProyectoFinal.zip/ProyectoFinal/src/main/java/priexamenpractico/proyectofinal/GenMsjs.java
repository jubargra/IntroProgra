/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package priexamenpractico.proyectofinal;

/**
 *
 * @author Dell
 */
public class GenMsjs {
    String msj = "";
    
//Metodos: 
// CrearMensaje: la compra y venta de jugadores se hace mediante el envio de mensajes con cierto formato a un grupo en whatsapp en donde estan todos los participantes.
// este metodo permite al usuario introducir informacion sobre el jugador que desea comprar y obtener un mensaje que cumpla con los requirimientos de formato. Esto es importante
// porque el envio en formatos incorrectos conlleva una multa al presupuesto.    
// ImprimirMensaje: permite al usuario obtener una lista de mensajes que facilitan la compra y venta de jugadores durante el mercado.
}
