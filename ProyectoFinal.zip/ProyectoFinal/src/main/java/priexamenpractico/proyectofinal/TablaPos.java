/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package priexamenpractico.proyectofinal;

/**
 *
 * @author Dell
 */
public class TablaPos {
        String escudo = "";
    int puntos = 0;
    int partJugs = 0;
    int partGana = 0;
    int partPerd = 0;
    int golesFav = 0;
    int golesContra = 0;
    int difGol = 0;
    
//Metodos: 
//    LlenarTabla permitira al usuario introducir el nombre de los equipos que disputaran el torneo en una tabla de posiciones.
//    IntroducirResultado sera el metodo indicado para introducir los resultados de los partidos a la tabla.
//    ImprimirResultados permite al usuario obtener una lista con los resultados de los partidos jugados.
//    ImprimirTabla: permite al usuario obtener los posiciones actuales de los equipos luego de introducir los resultados.
    
    
}
