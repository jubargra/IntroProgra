/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package priexamenpractico.proyectofinal;

/**
 *
 * @author Dell
 */
public class Calendario {
    
    String equiVis = "";
    String equiCas = "";
    String jornad = equiVis+" vs. "+equiCas;
    
    // Metodos:
    // CrearJornadas permitirá introducir los nombres de los equipos en una lista y realizar los emparejamientos de manera que cada equipo juegue
    // un partido en casa y uno de visita contra cada jugador.
    // ImprimirCalendario permitira al usuario imprimir una lista con las jornadas por jugar. A cada semana se le asignara una cantidad de jornadas por jugar.
}
