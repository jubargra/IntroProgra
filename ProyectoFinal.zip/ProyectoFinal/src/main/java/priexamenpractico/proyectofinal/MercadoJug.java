/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package priexamenpractico.proyectofinal;

/**
 *
 * @author Dell
 */
public class MercadoJug {
    String clubOrig = "";
    String clubDest = "";
    String nombJug = "";
    String global = "";
    int precioJug = 0;
    
    //Metodos: 
    // MovimientoJug permite al usuario registrar los movimientos de jugadores entre equipos, solictara informacion relacionada
    // con el club de origen, el club de destino, nombre del jugador y su calificacion, monto de la transaccion.
    // ImprimirMovimientos permite obtener una lista de los movimientos que se registraron durante el mercado.
}
