/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package priexamenpractico.proyectofinal;

/**
 *
 * @author Dell
 */
public class Presupuesto {
    
    String usuario = "";
    String equipo = "";
    int entradas = 0;
    int salidas = 0;
    int total = 0;
    String descrMov = "";
    String fecha = "";
    
//Metodos: llenarPresupuesto: permite asignar una cantidad inicial de dinero a todos los jugadores.
//         ModificarCampo: permite reigstrar transacciones como entradas y salidas de dinero al presupuesto 
//         asi como agregar una descripcion de la transaccion (multas, premios, venta y compra de jugadores).
           
    
}
