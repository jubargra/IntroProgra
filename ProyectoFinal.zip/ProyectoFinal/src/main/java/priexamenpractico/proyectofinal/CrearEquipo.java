/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package priexamenpractico.proyectofinal;

/**
 *
 * @author Dell
 */
public class CrearEquipo {
    String usuario = "";
    String nombJug = "";
    String escudo = "";
    
    
//Metodos: LlenarEquipo: este metodo permitira almacenar un usuario, una cantidad determinada de jugadores y el nombre del club que utilizaran durante el torneo mediante arreglos y ciclos.
    
    
}
