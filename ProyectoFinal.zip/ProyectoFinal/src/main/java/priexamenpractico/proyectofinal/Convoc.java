/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package priexamenpractico.proyectofinal;

/**
 *
 * @author Dell
 */
public class Convoc {
    String listaCas[] = new String[15];
    String listaVis[] = new String[15];

   // Metodos
  //  LlenarListaCas: permite al entrenador del equipo Casa convocar a 15 jugadores para el partido.
  //  LlenarListaVis: permite al entrenador del equipo Visita convocar a 15 jugadores para el partido.
  // ImprimirConvocatoria: imprime ambar listas ademas de un titulo donde se especifico los equipos que juegan.

    
    
}
